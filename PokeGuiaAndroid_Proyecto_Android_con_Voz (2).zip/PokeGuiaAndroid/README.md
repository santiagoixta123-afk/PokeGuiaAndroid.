# PokeGuía para Android — prototipo 0.2

App nativa Android con interfaz en español, buscador local offline, botón para dictar consultas y botón para leer en voz alta la respuesta. Utiliza reconocimiento de voz y TextToSpeech integrados en Android; reconocimiento puede depender de conexión, permisos y servicios instalados/configurados en el dispositivo.

## Estado honesto
- Incluye voz de entrada y salida implementada en Android.
- Responde mediante búsqueda en fichas integradas, **no es una IA generativa real** y no consulta fuentes actuales.
- No guarda ni envía las consultas hechas al buscador local.
- La entrada por voz la procesa el servicio de reconocimiento que tenga configurado Android; el comportamiento de privacidad depende de ese servicio.
- No se ha podido compilar/probar el APK en este entorno porque no hay Java, Gradle ni Android SDK instalados.

## Obtener el APK sin pagar
1. Crea un repositorio privado o público en GitHub y sube el contenido de esta carpeta (no el ZIP dentro de otra carpeta).
2. Abre **Actions** y habilita los workflows si GitHub lo pide.
3. Ejecuta **Compilar APK de PokeGuía** con **Run workflow** (o sube el proyecto a la rama `main`).
4. Al terminar, abre la ejecución y descarga el artefacto **PokeGuia-Android-debug**.
5. Extrae el archivo descargado; instala `app-debug.apk` en Android. Si el sistema lo solicita, permite la instalación desde el origen que usaste.

El APK de depuración no está firmado para publicación en Play Store. El proyecto se puede importar también en Android Studio con JDK 17 y SDK Android 35; ejecuta `gradle assembleDebug`.
