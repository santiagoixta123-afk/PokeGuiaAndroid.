package com.pokeguia.android;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_MIC = 310;
    private static final int REQ_SPEECH = 311;
    private final int bg = Color.rgb(16,23,38), panel = Color.rgb(25,35,56), line = Color.rgb(51,66,94), fg = Color.rgb(242,245,251), muted = Color.rgb(171,183,202), blue = Color.rgb(120,189,255), gold = Color.rgb(255,211,110);
    private LinearLayout content, results;
    private EditText input;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String lastAnswer = "";
    private final String[][] entries = {
        {"Amuleto Moneda (Amulet Coin)","Objetos y recompensas","dinero yenes moneda amulet coin entrenadores","La información aportada indica un bono de +50% al dinero de combates contra entrenadores durante 1 hora. Confirma el efecto y duración en la descripción del objeto dentro del juego antes de planear una ruta."},
        {"Amuletos de riqueza +75% / +100%","Objetos y recompensas","dinero riches charm riqueza amuletos","Se mencionan versiones de +75% y +100%, con obtención por eventos o tienda. La disponibilidad, acumulación y duración pueden cambiar; compruébalas en el juego."},
        {"Amuletos de experiencia","Objetos y recompensas","exp experiencia subir nivel amuletos","Se mencionan bonos de experiencia de 25%, 50% y 100% por 1 hora. Confirma la versión exacta, duración y compatibilidad con otros bonos en la descripción del objeto."},
        {"Piedra Eterna (Everstone)","Crianza","piedra eterna everstone naturaleza crianza","La guía recibida indica que transmite la naturaleza del progenitor que la lleva al Pokémon obtenido por crianza. Confirma las reglas actuales y cuál progenitor la sostiene antes de consumir a los padres."},
        {"Objetos Recios (Power Items)","Crianza","recio power item iv crianza pesa recia brazal recio cinto recio lente recia banda recia franja recia","La lista aportada asocia Pesa Recia con PS, Brazal Recio con Ataque, Cinto Recio con Defensa, Lente Recia con Ataque Especial, Banda Recia con Defensa Especial y Franja Recia con Velocidad. La herencia exacta en PokéMMO puede diferir o cambiar: verifica la descripción y el sistema actual antes de criar."},
        {"Probabilidad de variocolor (shiny)","Encuentros","shiny variocolor probabilidad amuleto shiny donador horda","La información proporcionada cita 1/30,000 como base y 1/27,272 con un bono de +10%. Estas cifras y la forma en que se acumulan Amuleto Shiny, estado Donador o Link de Horda necesitan confirmación actual. No son una garantía de encuentro."},
        {"GTL y economía","Economía","gtl gts mercado comisión venta compra economía","El GTL permite consultar ofertas de jugadores, incluidos Pokémon y objetos según las reglas actuales. Revisa el precio final, la comisión mostrada en el juego y ofertas comparables antes de publicar o comprar."},
        {"Revancha de líderes y farmeo","Economía","farmear farmeo dinero gimnasio líderes torkoal typhlosion blastoise amulet coin","La propuesta recibida menciona revanchas de líderes con equipos de daño en área y Amuleto Moneda. La rentabilidad depende del equipo, región, bonos, límites y cambios del juego. Compara el tiempo y gasto antes de invertir."},
        {"Crianza: aviso sobre los padres","Crianza","padres consumen desaparecen huevo crianza importante","La guía recibida advierte que los padres se consumen al obtener el huevo en PokéMMO. Trátalo como una acción irreversible y confirma el aviso de la guardería antes de aceptar; no entregues Pokémon valiosos por error."},
        {"IVs y EVs","Entrenamiento","ivs evs estadísticas entrenamiento 252 510","IVs son valores individuales de cada estadística; EVs son puntos de esfuerzo que se obtienen mediante entrenamiento u objetos. La información recibida indica máximo de 252 EV por estadística y 510 en total. Verifica los límites y el método vigente en el juego."},
        {"Naturalezas","Entrenamiento","naturaleza firme adamant alegre jolly estadísticas","La mayoría de las naturalezas sube una estadística y baja otra. Ejemplos aportados: Firme (Adamant) favorece Ataque y reduce Ataque Especial; Alegre (Jolly) favorece Velocidad y reduce Ataque Especial. Revisa la naturaleza concreta en la ficha del Pokémon."},
        {"Tiers competitivos","PvP","pvp ou uu nu untiered lc tiers metagame","OU, UU y NU son categorías de uso competitivo; LC corresponde a Little Cup, con restricciones propias. La clasificación y elegibilidad de cada Pokémon cambian según el formato y el metajuego: consulta la lista vigente antes de armar el equipo."}
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        tts = new TextToSpeech(this, this);
        buildUi();
    }
    @Override public void onInit(int status) {
        if(status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("es", "MX"));
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            if(!ttsReady) ttsReady = tts.setLanguage(new Locale("es")) >= TextToSpeech.LANG_AVAILABLE;
        }
    }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); if(bold) v.setTypeface(null,1); v.setLineSpacing(dp(2),1f); return v;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(20),dp(16),dp(28)); scroll.addView(content); setContentView(scroll);
        TextView title = text("⚡ PokeGuía",25,fg,true); content.addView(title);
        TextView subtitle = text("Asistente de PokéMMO · prototipo Android",13,muted,false); subtitle.setPadding(0,dp(3),0,dp(15)); content.addView(subtitle);
        LinearLayout hero = box(); hero.addView(text("Tu guía de bolsillo",20,fg,true));
        TextView intro=text("Pregunta por voz o texto sobre crianza, amuletos, economía, IVs/EVs y PvP. La búsqueda funciona sin internet.",14,muted,false); intro.setPadding(0,dp(8),0,dp(10)); hero.addView(intro);
        TextView caution=text("Ojo: este prototipo busca en fichas preparadas; no es una IA generativa ni consulta datos en vivo. Confirma en el juego las cifras o mecánicas que pueden cambiar.",13,gold,false); hero.addView(caution);
        LinearLayout ask=box(); ask.addView(text("Haz una consulta",16,fg,true));
        input = new EditText(this); input.setSingleLine(false); input.setMinLines(1); input.setMaxLines(3); input.setTextSize(15); input.setHint("Ej.: ¿qué hace la Piedra Eterna?"); input.setHintTextColor(muted); input.setTextColor(fg); input.setPadding(dp(12),dp(10),dp(12),dp(10)); input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(line));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.topMargin=dp(10); ask.addView(input,ip);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER_VERTICAL); actions.setPadding(0,dp(9),0,dp(4));
        Button search=button("Buscar"); search.setOnClickListener(v->search(input.getText().toString())); actions.addView(search,new LinearLayout.LayoutParams(0,dp(48),1));
        Button speak=button("🎙 Hablar"); speak.setOnClickListener(v->startVoice()); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(48),1); sp.leftMargin=dp(8); actions.addView(speak,sp); ask.addView(actions);
        Button replay=button("🔊 Leer última respuesta"); replay.setOnClickListener(v->speakAnswer()); ask.addView(replay,new LinearLayout.LayoutParams(-1,dp(45)));
        results=new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); results.setPadding(0,dp(8),0,0); ask.addView(results);
        TextView topics=text("TEMAS INCLUIDOS",13,gold,true); topics.setPadding(dp(4),dp(10),0,dp(8)); content.addView(topics);
        LinearLayout cards=box(); cards.addView(text("🪙 Objetos y recompensas\n🥚 Crianza y Recios\n📈 IVs, EVs y naturalezas\n🏆 GTL, farmeo y PvP",14,fg,false)); 
        TextView footer=text("PokeGuía es un proyecto de fans, no oficial ni afiliado a PokéMMO o Pokémon. La voz usa reconocimiento y síntesis de Android; disponibilidad y procesamiento dependen del servicio/configuración del dispositivo. Las búsquedas de fichas se realizan en el teléfono.",11,muted,false); footer.setGravity(Gravity.CENTER); footer.setPadding(dp(8),dp(14),dp(8),0); content.addView(footer);
    }
    private LinearLayout box(){ LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(14),dp(14),dp(14)); android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(panel);d.setCornerRadius(dp(18));d.setStroke(dp(1),line);l.setBackground(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(12);content.addView(l,p);return l; }
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(Color.rgb(12,26,45));b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));return b;}
    private void search(String query){
        String q=normalize(query); if(q.trim().isEmpty()){Toast.makeText(this,"Escribe o dicta una pregunta primero.",Toast.LENGTH_SHORT).show();return;}
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);
        String[] terms=q.split("[^a-z0-9]+" ); ArrayList<int[]> scores=new ArrayList<>();
        for(int i=0;i<entries.length;i++){String hay=normalize(entries[i][0]+" "+entries[i][1]+" "+entries[i][2]+" "+entries[i][3]);int score=0;for(String term:terms){if(term.length()>1&&hay.contains(term))score+= (normalize(entries[i][0]+" "+entries[i][2]).contains(term)?3:1);}if(score>0)scores.add(new int[]{i,score});}
        Collections.sort(scores,(a,b)->b[1]-a[1]);results.removeAllViews();
        if(scores.isEmpty()){TextView none=text("No encontré una ficha coincidente. Prueba con crianza, shiny, moneda, EVs o GTL.",14,muted,false);results.addView(none);lastAnswer="No encontré una ficha coincidente. Prueba con crianza, shiny, moneda, EVs o GTL.";return;}
        StringBuilder spoken=new StringBuilder();int count=Math.min(4,scores.size());
        for(int n=0;n<count;n++){String[] item=entries[scores.get(n)[0]];LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(12),dp(11),dp(12),dp(11));android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(Color.rgb(32,45,69));d.setCornerRadius(dp(13));d.setStroke(dp(1),line);card.setBackground(d);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(7);results.addView(card,cp);card.addView(text(item[0],15,fg,true));TextView cat=text(item[1],11,blue,false);cat.setPadding(0,dp(3),0,dp(5));card.addView(cat);card.addView(text(item[3],13,muted,false));if(n>0)spoken.append(". ");spoken.append(item[0]).append(". ").append(item[3]);}
        lastAnswer=spoken.toString();
    }
    private String normalize(String s){return java.text.Normalizer.normalize(s.toLowerCase(new Locale("es","MX")),java.text.Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+","");}
    private void startVoice(){
        if(!SpeechRecognizer.isRecognitionAvailable(this)){Toast.makeText(this,"No hay reconocimiento de voz disponible en este dispositivo.",Toast.LENGTH_LONG).show();return;}
        if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_MIC);return;}
        launchRecognizer();
    }
    private void launchRecognizer(){try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es-MX");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"es-MX");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Haz tu pregunta sobre PokéMMO");startActivityForResult(i,REQ_SPEECH);}catch(Exception e){Toast.makeText(this,"No se pudo abrir el reconocimiento de voz.",Toast.LENGTH_LONG).show();}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQ_MIC&&grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)launchRecognizer();else if(requestCode==REQ_MIC)Toast.makeText(this,"Para dictar hace falta permiso de micrófono. También puedes escribir.",Toast.LENGTH_LONG).show();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_SPEECH&&resultCode==RESULT_OK&&data!=null){ArrayList<String> matches=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(matches!=null&&!matches.isEmpty()){input.setText(matches.get(0));search(matches.get(0));}}}
    private void speakAnswer(){if(lastAnswer.isEmpty()){Toast.makeText(this,"Primero haz una búsqueda.",Toast.LENGTH_SHORT).show();return;}if(ttsReady)tts.speak(lastAnswer,TextToSpeech.QUEUE_FLUSH,null,"pokeguia-answer");else Toast.makeText(this,"La voz de salida aún no está disponible. Revisa el motor de texto a voz de Android.",Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
